from controller import Controller

# Run the program
if __name__ == '__main__':
    Controller.run_simulation()
